# A user-defined format
CUSTOM_DAY_FORMAT = 'd/m/Y CUSTOM'
